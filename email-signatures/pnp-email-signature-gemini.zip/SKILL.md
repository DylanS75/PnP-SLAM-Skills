---
name: pnp-email-signature
description: Build a new Plug and Play employee's official Gmail email signature from a short interview, following the PNPTC Knowledge Base "Email Signatures" page. Use when someone asks to make, set up, create, update or fix their Plug and Play email signature, Gmail signature, or signature block, or is doing new-hire onboarding and gets to the email signature step.
---

# Plug and Play email signature

This skill replaces the manual steps on the HR Confluence page "Email Signatures" (PNPTC Knowledge Base). Instead of the employee clicking through Gmail's insert-image and insert-link dialogs, you collect their details, build the finished signature, and either hand it over ready to paste or set it in Gmail for them.

The official layout, top to bottom:

1. **First Name Last Name** in bold
2. Job title, not bold
3. Plug and Play logo, small
4. Website link: plugandplaytechcenter.com
5. A clickable banner (Company Report 2025 or 20th Anniversary Book)
6. Mandatory line, in italics: "Update your *email preferences* to choose the types of emails you receive from us." with "email preferences" linked

Optional lines the person can add go between the job title and the logo. Never change the order of the official items, never drop the mandatory preferences line, and never swap in a different logo or banner.

## Step 1: Interview

Ask for everything in one message so the person can answer in one go. Keep it friendly and short. Ask for:

**Required**
- First name and last name, exactly as they should appear (check capitalization and accents)
- Job title, exactly as it should appear

**Banner choice** (show both, ask them to pick one)
- Company Report 2025 ("Dig into the numbers... Read the Report")
- 20th Anniversary Book ("See how Plug and Play became a global innovation platform... Access the Book")
- If they are unsure, suggest checking with their manager or marketing about which one their team is using right now.

**Optional** (say clearly they can skip any of these)
- Pronouns
- Phone number
- Office location (for example "Bentonville, AR" or "Sunnyvale, CA")
- LinkedIn profile URL

**Delivery**
- Do they want a ready-to-paste signature, or (only if you can control a web browser in this session) do they want you to set it in Gmail for them? If you cannot control a browser, do not offer the second option, just build the paste version.

If an answer is ambiguous (for example a title in all lowercase, or a phone number with no country code for someone outside the US), confirm it before building. Do not invent or "improve" job titles.

## Step 2: Build the signature

Fill in `assets/signature-template.html`. It contains the full signature with every URL already set. Rules:

- Replace `{{FULL_NAME}}` and `{{JOB_TITLE}}`.
- Replace `{{PRONOUNS_SUFFIX}}` with a space and the pronouns in parentheses, for example ` (she/her)`, so they sit after the bold name without being bold. If no pronouns were given, replace it with nothing.
- For each optional field the person gave, keep its line and fill it in. Delete the whole line for any field they skipped. Phone and location share one line separated by `&nbsp;|&nbsp;` when both are present.
- Keep exactly one banner block (the one they picked) and delete the other.
- Escape `&`, `<` and `>` in anything the person typed.
- Do not change any URL, image size or style in the template. Banner URLs and link targets are listed in `references/assets-and-links.md` if you need to check them.

## Step 3: Deliver

### Option A: ready to paste (default, works everywhere)

1. Fill in `assets/preview-page.html` by replacing `{{SIGNATURE_HTML}}` with the signature you built. This page shows the signature and has a **Copy signature** button that copies it as formatted text.
2. Give the person that page as an HTML file they can open in their browser, or as a rendered preview if your tool can show HTML.
3. Give them these steps (keep them this short):
   1. Open the page and click **Copy signature**. (If the button does not work, drag to select the signature in the preview and press Ctrl+C or Cmd+C.)
   2. In Gmail, click the gear icon, then **See all settings**. On the **General** tab, scroll to **Signature** and click **Create new**. Name it something like "PNP".
   3. Click into the signature box, paste with Ctrl+V or Cmd+V, then under **Signature defaults** choose this signature for new emails and for replies/forwards. Scroll to the bottom and click **Save Changes**.
4. Remind them to send a test email to themselves and check that the logo and banner show up and the banner link opens.

Never paste raw HTML code into Gmail's signature box. It has to be the rendered, formatted version.

### Option B: set it in Gmail for them (only with browser control)

Follow `references/gmail-browser-setup.md`. The key rules:

- Show the person the finished signature (Option A preview) and get a clear yes before touching Gmail.
- Work only in the person's own signed-in Gmail. Never ask for or type their password.
- Saving Gmail settings changes their account, so confirm before clicking **Save Changes**, then confirm it saved.
- If anything in the browser fails twice, stop and fall back to Option A.

## Final checks

Before handing anything over, confirm:

- Name is bold, title is not, and both are spelled exactly as given
- Logo is the Plug and Play logo from the template, at the template's small size
- The website link reads plugandplaytechcenter.com and points to https://www.plugandplaytechcenter.com/
- Exactly one banner is present, it is the one they chose, and clicking it goes to that banner's landing page
- The mandatory preferences line is present, in italics, with "email preferences" linked
- No placeholder text like `{{` remains, and no empty optional lines are left behind
