# Signature assets and links

Source: PNPTC Knowledge Base (Confluence, HR space), page "Email Signatures". Checked November 2026. If HR updates that page (new banner, new logo, new mandatory text), update this file and `assets/signature-template.html` together.

## Logo

- Image: https://3340630.fs1.hubspotusercontent-na1.net/hubfs/3340630/Email%20Signatures/PlugAndPlay%20Logo%20signature.png
- Native size 400 x 144. The Confluence page says to resize to Gmail's "small", so the template shows it at 100 x 36.

## Website

- Text: plugandplaytechcenter.com
- Link: https://www.plugandplaytechcenter.com/

## Banners (pick one)

Both banners are 350 x 100 images stored in Google Drive. The Confluence page links them as Drive "view" pages, which do not work as an image source. The template uses the direct image form of the same files.

| Banner | Drive file (as on Confluence) | Image URL used in template | Click-through link |
|---|---|---|---|
| Company Report 2025 | https://drive.google.com/file/d/1IpCbbMe4R_Y3vGjOwmEXH7LNCK8kwauY/view | https://lh3.googleusercontent.com/d/1IpCbbMe4R_Y3vGjOwmEXH7LNCK8kwauY | https://welcome.plugandplaytechcenter.com/company-performance-report-2025 |
| 20th Anniversary Book | https://drive.google.com/file/d/1R175VhnW_IAEEvK6OdsGcWgHOnRgWdpH/view | https://lh3.googleusercontent.com/d/1R175VhnW_IAEEvK6OdsGcWgHOnRgWdpH | https://welcome.plugandplaytechcenter.com/20-year-anniversary-book |

If a banner shows as a broken image in a test email, the Drive file's sharing may have changed. Fallback: in Gmail's signature editor, delete the broken image, click **Insert image**, choose the **Google Drive** tab, find the banner file, insert it, then select it and use **Insert link** to add the click-through link above.

## Mandatory text

"Update your email preferences to choose the types of emails you receive from us."

- Italic
- "email preferences" links to https://email.plugandplaytechcenter.com/hs/preferences-center/en/page
