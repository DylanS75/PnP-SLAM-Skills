# Setting the signature in Gmail with browser control

Use this only when you can control the person's web browser and they asked you to set the signature for them. If you cannot, use the paste option in SKILL.md.

## Ground rules

- Work in the person's own Gmail, already signed in. If Gmail asks for a sign-in, stop and ask the person to sign in themselves. Never ask for or type a password.
- Show the finished signature and get a clear yes before you start.
- Saving settings changes their account. Confirm once more right before clicking **Save Changes**.
- If a step fails twice, stop, tell the person what happened, and give them the paste version instead.
- Don't change any other Gmail setting.

## Steps

1. Go to `https://mail.google.com/mail/u/0/#settings/general`. (If they use more than one Google account, check the account shown in the top right is their Plug and Play address. If not, ask which one.)
2. Scroll to the **Signature** section.
3. If a signature named "PNP" (or an older Plug and Play signature) already exists, ask whether to replace it or create a new one.
4. Click **Create new**, enter the name "PNP", and click **Create**.
5. Put the signature into the editor. Preferred method: the signature editor is an editable box (`div[contenteditable="true"]` inside the Signature section). If you can run a script in the page, set that box's HTML to the signature you built (signature only, not the preview page), then fire an `input` event on it so Gmail registers the change. Otherwise, open the preview page, use its Copy button, return to Gmail, click into the editor and paste.
6. Look at the editor and check it matches the preview: bold name, title, logo, website link, banner, italic preferences line. If the logo or banner shows as a broken image, use the Google Drive fallback in `assets-and-links.md`.
7. Under **Signature defaults**, set **For new emails use** and **On reply/forward use** to "PNP" for their Plug and Play address.
8. Confirm with the person, then scroll to the bottom of the page and click **Save Changes**.
9. Check it saved: reopen settings and confirm the "PNP" signature is there, or open a new Compose window and confirm the signature appears. Close the compose draft without sending.
10. Tell the person it's done and suggest they send themselves a test email to check the banner link.

## Manual steps from the Confluence page (fallback reference)

If the script and paste methods both fail, these are the original click-by-click steps:

1. Settings, See all settings, General, Signature, Create new.
2. Type First Name Last Name and make it bold. New line, job title, not bold.
3. Insert image, Web Address (URL), paste the logo URL, resize to Small.
4. Add the website: plugandplaytechcenter.com
5. Insert image, Google Drive, pick the chosen banner. Resize if needed. Select it, Insert link, add the banner's click-through link.
6. Add the mandatory line in italics and link "email preferences".
